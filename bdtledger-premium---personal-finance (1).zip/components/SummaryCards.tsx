
import React from 'react';
import { Wallet, PiggyBank, BarChart3, TrendingUp, TrendingDown } from 'lucide-react';
import { SummaryStats } from '../types';

interface SummaryCardsProps {
  stats: SummaryStats;
}

const SummaryCards: React.FC<SummaryCardsProps> = ({ stats }) => {
  const formatCurrency = (amount: number) => {
    return `৳${amount.toLocaleString('en-BD')}`;
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
      {/* Total Balance / Savings Card */}
      <div className="glass rounded-3xl p-6 relative overflow-hidden group hover:bg-white/10 transition-colors">
        <div className="absolute top-0 right-0 p-4 opacity-20">
          <PiggyBank className="w-20 h-20 text-yellow-500 group-hover:scale-110 transition-transform" />
        </div>
        <div className="relative z-10">
          <p className="text-slate-400 text-sm font-medium mb-1">Total Savings</p>
          <h3 className="text-3xl font-bold mb-4">
            {formatCurrency(stats.totalSavings)}
          </h3>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-yellow-500">
            <Wallet className="w-4 h-4" />
            Account Balance
          </div>
        </div>
      </div>

      {/* Cash In Summary */}
      <div className="glass rounded-3xl p-6 relative overflow-hidden group hover:bg-white/10 transition-colors">
         <div className="absolute top-0 right-0 p-4 opacity-20">
          <TrendingUp className="w-20 h-20 text-emerald-500 group-hover:scale-110 transition-transform" />
        </div>
        <div className="relative z-10">
          <p className="text-slate-400 text-sm font-medium mb-1">Total Cash In</p>
          <h3 className="text-3xl font-bold mb-4 text-emerald-400">
            {formatCurrency(stats.totalCashIn)}
          </h3>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-500">
            <TrendingUp className="w-4 h-4" />
            Money Received
          </div>
        </div>
      </div>

      {/* Total Volume Card */}
      <div className="glass rounded-3xl p-6 relative overflow-hidden group hover:bg-white/10 transition-colors">
        <div className="absolute top-0 right-0 p-4 opacity-20">
          <BarChart3 className="w-20 h-20 text-blue-500 group-hover:scale-110 transition-transform" />
        </div>
        <div className="relative z-10">
          <p className="text-slate-400 text-sm font-medium mb-1">Total Volume</p>
          <h3 className="text-3xl font-bold mb-4 text-blue-300">
            {formatCurrency(stats.totalVolume)}
          </h3>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-blue-500">
            <BarChart3 className="w-4 h-4" />
            Total Transaction
          </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryCards;
