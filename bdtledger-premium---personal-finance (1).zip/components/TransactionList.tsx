
import React from 'react';
import { Trash2, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { Transaction } from '../types';

interface TransactionListProps {
  transactions: Transaction[];
  onDelete: (id: string) => void;
}

const TransactionList: React.FC<TransactionListProps> = ({ transactions, onDelete }) => {
  return (
    <div className="space-y-3 overflow-y-auto max-h-[600px] pr-2 custom-scrollbar">
      {transactions.length === 0 ? (
        <div className="text-center py-10 glass rounded-2xl">
          <p className="text-slate-500">No transactions recorded yet.</p>
        </div>
      ) : (
        transactions.map((tx) => (
          <div 
            key={tx.id} 
            className="glass p-4 rounded-2xl flex items-center justify-between group hover:bg-white/10 transition-all border-l-4"
            style={{ borderLeftColor: tx.type === 'cash-in' ? '#10b981' : '#f43f5e' }}
          >
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tx.type === 'cash-in' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                {tx.type === 'cash-in' ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
              </div>
              <div>
                <h4 className="font-semibold text-slate-100">{tx.personName}</h4>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span>{tx.date}</span>
                  <span>•</span>
                  <span>{tx.category}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className={`font-bold ${tx.type === 'cash-in' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {tx.type === 'cash-in' ? '+' : '-'} ৳{tx.amount.toLocaleString()}
                </p>
                <p className="text-[10px] uppercase font-semibold text-slate-500">
                  {tx.type === 'cash-in' ? 'Received' : 'Sent'}
                </p>
              </div>
              <button 
                onClick={() => onDelete(tx.id)}
                className="p-2 rounded-lg hover:bg-rose-500/20 text-rose-500/40 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default TransactionList;
