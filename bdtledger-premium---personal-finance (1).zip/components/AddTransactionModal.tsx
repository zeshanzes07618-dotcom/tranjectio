
import React, { useState } from 'react';
import { X } from 'lucide-react';
import { TransactionType } from '../types';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (tx: {
    personName: string;
    amount: number;
    type: TransactionType;
    date: string;
    category: string;
  }) => void;
}

const AddTransactionModal: React.FC<AddTransactionModalProps> = ({ isOpen, onClose, onAdd }) => {
  const [personName, setPersonName] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<TransactionType>('cash-in');
  const [date, setDate] = useState('2026-02-15');
  const [category, setCategory] = useState('General');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personName || !amount) return;
    
    onAdd({
      personName,
      amount: parseFloat(amount),
      type,
      date,
      category
    });

    // Reset fields
    setPersonName('');
    setAmount('');
    setType('cash-in');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative glass w-full max-w-md rounded-3xl overflow-hidden border border-white/20 shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="royal-blue-gradient p-6 flex justify-between items-center">
          <h2 className="text-xl font-bold">New Transaction</h2>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded-full">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4 bg-slate-900/40">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-1">Person's Name</label>
            <input 
              required
              type="text" 
              value={personName}
              onChange={(e) => setPersonName(e.target.value)}
              placeholder="e.g. Rahim Ahmed"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Amount (BDT)</label>
              <input 
                required
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500 transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Date</label>
              <input 
                required
                type="date" 
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500 transition-colors text-slate-300"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2 text-center">Transaction Type</label>
            <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
              <button
                type="button"
                onClick={() => setType('cash-in')}
                className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${type === 'cash-in' ? 'bg-emerald-500 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
              >
                CASH IN
              </button>
              <button
                type="button"
                onClick={() => setType('cash-out')}
                className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${type === 'cash-out' ? 'bg-rose-500 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
              >
                CASH OUT
              </button>
            </div>
            <p className="mt-2 text-[10px] text-slate-500 text-center uppercase tracking-tighter">
              {type === 'cash-in' ? 'You received money (They owe you less / You owe them more)' : 'You gave money (They owe you more / You owe them less)'}
            </p>
          </div>

          <button 
            type="submit"
            className="w-full mt-4 royal-blue-gradient py-4 rounded-xl font-bold text-lg shadow-xl hover:shadow-blue-500/20 active:scale-95 transition-all"
          >
            Confirm Transaction
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddTransactionModal;
