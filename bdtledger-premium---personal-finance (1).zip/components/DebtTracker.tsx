
import React, { useMemo } from 'react';
import { Users, UserPlus, UserMinus } from 'lucide-react';
import { Transaction } from '../types';

interface DebtTrackerProps {
  transactions: Transaction[];
}

const DebtTracker: React.FC<DebtTrackerProps> = ({ transactions }) => {
  const debts = useMemo(() => {
    const people: Record<string, { owedToMe: number; owedByMe: number }> = {};

    transactions.forEach(t => {
      if (!people[t.personName]) {
        people[t.personName] = { owedToMe: 0, owedByMe: 0 };
      }
      if (t.type === 'cash-out') {
        // I gave money to them, they owe me
        people[t.personName].owedToMe += t.amount;
      } else {
        // They gave money to me, I owe them
        people[t.personName].owedByMe += t.amount;
      }
    });

    return Object.entries(people).map(([name, data]) => ({
      name,
      net: data.owedToMe - data.owedByMe
    })).filter(p => p.net !== 0);
  }, [transactions]);

  const theyOweMe = debts.filter(d => d.net > 0);
  const iOweThem = debts.filter(d => d.net < 0);

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold flex items-center gap-2">
        <Users className="w-5 h-5 text-yellow-500" />
        Debt Tracker
      </h2>
      
      <div className="space-y-4">
        {/* They owe me */}
        <div className="glass rounded-2xl p-5 border-emerald-500/20">
          <h4 className="text-sm font-bold text-emerald-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <UserPlus className="w-4 h-4" />
            They Owe Me
          </h4>
          <div className="space-y-3">
            {theyOweMe.length > 0 ? theyOweMe.map((d, i) => (
              <div key={i} className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
                <span className="font-medium">{d.name}</span>
                <span className="font-bold text-emerald-400">৳{d.net.toLocaleString()}</span>
              </div>
            )) : (
              <p className="text-slate-500 text-sm italic">Clear as day. No one owes you.</p>
            )}
          </div>
        </div>

        {/* I owe them */}
        <div className="glass rounded-2xl p-5 border-red-500/20">
          <h4 className="text-sm font-bold text-rose-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <UserMinus className="w-4 h-4" />
            I Owe Them
          </h4>
          <div className="space-y-3">
            {iOweThem.length > 0 ? iOweThem.map((d, i) => (
              <div key={i} className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
                <span className="font-medium">{d.name}</span>
                <span className="font-bold text-rose-400">৳{Math.abs(d.net).toLocaleString()}</span>
              </div>
            )) : (
              <p className="text-slate-500 text-sm italic">Excellent. You owe no one.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DebtTracker;
