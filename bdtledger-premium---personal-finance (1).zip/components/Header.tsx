
import React, { useState } from 'react';
import { Calendar, UserCircle } from 'lucide-react';

interface HeaderProps {
  userName: string;
  onEditName: (name: string) => void;
}

const Header: React.FC<HeaderProps> = ({ userName, onEditName }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(userName);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onEditName(tempName);
    setIsEditing(false);
  };

  return (
    <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-10 gap-4">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-3xl font-bold">Hello,</h1>
          {isEditing ? (
            <form onSubmit={handleSubmit} className="inline-block">
              <input 
                autoFocus
                type="text"
                value={tempName}
                onChange={(e) => setTempName(e.target.value)}
                onBlur={handleSubmit}
                className="bg-transparent border-b-2 border-yellow-500 text-3xl font-bold outline-none gold-text min-w-[150px]"
              />
            </form>
          ) : (
            <span 
              onClick={() => setIsEditing(true)}
              className="text-3xl font-bold gold-text cursor-pointer hover:opacity-80 transition-opacity"
            >
              {userName}
            </span>
          )}
        </div>
        <p className="text-slate-400 flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          February 2026 • Financial Ledger
        </p>
      </div>
      
      <div className="hidden sm:block">
        <div className="w-12 h-12 rounded-full glass flex items-center justify-center border-white/10 shadow-lg">
          <UserCircle className="w-8 h-8 text-blue-400" />
        </div>
      </div>
    </header>
  );
};

export default Header;
